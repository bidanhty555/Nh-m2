﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace QLKQHT
{
    public partial class QLGV : System.Web.UI.Page
    {
        string connect = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;
        string magv, tengv, lopcn, sdt, diachi;
        Boolean gt;
        DateTime ns;
        protected void Page_Load(object sender, EventArgs e)
        {
            DS_Load();
            ddlLopChuNhiem.Items.Add("6A");
            ddlLopChuNhiem.Items.Add("6B");
            ddlLopChuNhiem.Items.Add("6C");
            ddlLopChuNhiem.Items.Add("6D");
            ddlLopChuNhiem.Items.Add("7A");
            ddlLopChuNhiem.Items.Add("7B");
            ddlLopChuNhiem.Items.Add("7C");
            ddlLopChuNhiem.Items.Add("7D");
            ddlLopChuNhiem.Items.Add("8A");
            ddlLopChuNhiem.Items.Add("8B");
            ddlLopChuNhiem.Items.Add("8C");
            ddlLopChuNhiem.Items.Add("8D");
            ddlLopChuNhiem.Items.Add("9A");
            ddlLopChuNhiem.Items.Add("9B");
            ddlLopChuNhiem.Items.Add("9C");
            ddlLopChuNhiem.Items.Add("9D");
        }
        private void DS_Load()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "select * from GIAOVIEN";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                dgvDanhSachGiaoVien.DataSource =  dt;
                dgvDanhSachGiaoVien.DataSourceID = null;
                dgvDanhSachGiaoVien.DataBind();
            }
        }

        protected void dgvDanhSachGiaoVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string maGV = dgvDanhSachGiaoVien.SelectedRow.Cells[1].Text;
            using (SqlConnection conn = new SqlConnection(connect))
            {
                
                string sql = "select * from GIAOVIEN where MAGIAOVIEN=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", maGV);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    magv = (string)dr["MAGIAOVIEN"];
                    tengv = (string)dr["TENGIAOVIEN"];
                    gt = (Boolean)dr["GIOITINH"];
                    ns = (DateTime)dr["NGAYSINH"];
                    lopcn = (string)dr["LOPCHUNHIEM"];
                    sdt = (string)dr["SDT"];
                    diachi = (string)dr["DIACHI"];
                }
                
            }
            txtMaGiaoVien.Text = magv;
            txtMaGiaoVien.Enabled = false;
            txtTenGiaoVien.Text = tengv;
            if (gt == true)
            {
                RadioButtonList1.SelectedIndex = 0;
            }
            else
            {
                RadioButtonList1.SelectedIndex = 1;
            }
            txtNgaySinh.Text = ns.ToString();
            ddlLopChuNhiem.Text = lopcn;
            txtSoDienThoai.Text = sdt;
            txtDiaChi.Text = diachi;
        }

        protected void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {

                string sql = "update GIAOVIEN set TENGIAOVIEN=@ten,GIOITINH=@gt,NGAYSINH=@ns,LOPCHUNHIEM=@lopcn,SDT=@sdt,DIACHI=@diachi where MAGIAOVIEN=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", txtMaGiaoVien.Text.ToString());
                cmd.Parameters.AddWithValue("@ten", txtTenGiaoVien.Text.ToString());
                cmd.Parameters.AddWithValue("@gt", RadioButtonList1.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@ns", txtNgaySinh.Text.ToString());
                cmd.Parameters.AddWithValue("@lopcn", ddlLopChuNhiem.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@sdt", txtSoDienThoai.Text.ToString());
                cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.ToString());
                conn.Open();
                cmd.ExecuteNonQuery();
                DS_Load();
            }
        }

        protected void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "delete GIAOVIEN where MAGIAOVIEN=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", txtMaGiaoVien.Text.ToString());
                conn.Open();
                cmd.ExecuteNonQuery();
                DS_Load();
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                if (KiemTra()!=1) 
                { 
                string sql = "INSERT INTO GIAOVIEN (MAGIAOVIEN,TENGIAOVIEN,GIOITINH,NGAYSINH,LOPCHUNHIEM,SDT,DIACHI) VALUES (@ma,@ten,@gt,@ns,@lopcn,@sdt,@diachi)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", txtMaGiaoVien.Text.ToString());
                cmd.Parameters.AddWithValue("@ten", txtTenGiaoVien.Text.ToString());
                cmd.Parameters.AddWithValue("@gt", RadioButtonList1.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@ns", txtNgaySinh.Text.ToString());
                cmd.Parameters.AddWithValue("@lopcn", ddlLopChuNhiem.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@sdt", txtSoDienThoai.Text.ToString());
                cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.ToString());
                conn.Open();
                cmd.ExecuteNonQuery();
                DS_Load();
                Label2.Text = "Thêm giáo viên thành công!";
                } else Label2.Text = "Mã giáo viên đã tồn tại!";
            }
        }
        public int KiemTra()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string magv = txtMaGiaoVien.Text;
                string sql = "select * from GIAOVIEN where MAGIAOVIEN='" + magv+"'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
} 